#include "Globals.h"

float Globals::battleFactor = 1;