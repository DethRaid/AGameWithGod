#include "Input.h"

Input::Input(void)
{}

Input::~Input(void)
{}

bool Input::a = false;
bool Input::b = false;
bool Input::c = false;
bool Input::d = false;
bool Input::e = false;
bool Input::f = false;
bool Input::g = false;
bool Input::h = false;
bool Input::i = false;
bool Input::j = false;
bool Input::k = false;
bool Input::l = false;
bool Input::m = false;
bool Input::n = false;
bool Input::o = false;
bool Input::p = false;
bool Input::q = false;
bool Input::r = false;
bool Input::s = false;
bool Input::t = false;
bool Input::u = false;
bool Input::v = false;
bool Input::w = false;
bool Input::x = false;
bool Input::y = false;
bool Input::z = false;
bool Input::enter = false;