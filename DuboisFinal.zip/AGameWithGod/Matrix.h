#pragma once
class Matrix
{
public:
	Matrix(void);
	~Matrix(void);
};

