#pragma once
class Globals
{
public:
	static float battleFactor;
};

