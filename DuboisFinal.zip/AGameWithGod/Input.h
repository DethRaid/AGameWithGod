#pragma once
#include "stdafx.h"

class Input
{
public:
	Input(void);
	~Input(void);
	static bool a;
	static bool b;
	static bool c;
	static bool d;
	static bool e;
	static bool f;
	static bool g;
	static bool h;
	static bool i;
	static bool j;
	static bool k;
	static bool l;
	static bool m;
	static bool n;
	static bool o;
	static bool p;
	static bool q;
	static bool r;
	static bool s;
	static bool t;
	static bool u;
	static bool v;
	static bool w;
	static bool x;
	static bool y;
	static bool z;
	static bool enter;
};

