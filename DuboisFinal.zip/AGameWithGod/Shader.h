#pragma once
//Shader.h and Shader.cpp taken from http://www.swiftless.com/tutorials/glsl/7_texturing.html

#include "stdafx.h"
#include "Vector3.h"

class Shader {
public:
	Shader();
	Shader( const char *vsFile, const char *fsFile );
	~Shader();
	
    void init( const char *vsFile, const char *fsFile );
    
	void bind();
	void unbind();

	void setVariable( std::string, Vector3 );
	void setVariable( std::string, float );
	void setVariable( std::string, float, float, float, float );
	void setVariable( std::string, int );
	
	unsigned int id();

	static void validateProgram(GLuint);
	static void validateShader(GLuint, const char*);

private:
	unsigned int shader_id;
	unsigned int shader_vp;
	unsigned int shader_fp;
	static std::ofstream debug;
};